/* intformat.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* enums regarding integer constant notations                                */
/*                                                                           */
/*****************************************************************************/

#ifndef INTFORMAT_H
#define INTFORMAT_H

#include "datatypes.h"

#include <stddef.h>

typedef enum {
    eIntFormatNone,
    eIntFormatDefRadix, /* ... */
    eIntFormatMotBin,   /* %... */
    eIntFormatMotOct,   /* @... */
    eIntFormatMotHex,   /* $... */
    eIntFormatIntBin,   /* ...b */
    eIntFormatIntOOct,  /* ...o */
    eIntFormatIntQOct,  /* ...q */
    eIntFormatIntHex,   /* ...h */
    eIntFormatIBMBin,   /* b'...' */
    eIntFormatIBMOct,   /* o'...' */
    eIntFormatIBMXHex,  /* x'...' */
    eIntFormatIBMHHex,  /* h'...' */
    eIntFormatCBin,     /* 0b... */
    eIntFormatCOct,     /* 0... */
    eIntFormatCHex,     /* 0x... */
    eIntFormatNatHex    /* 0..., incompatible with eIntFormatCOct */
} tIntFormatId;

#define eIntFormatMaskC \
    ((1ul << eIntFormatCHex) | (1ul << eIntFormatCBin) | (1ul << eIntFormatCOct))
#define eIntFormatMaskIntel                                                             \
    ((1ul << eIntFormatIntHex) | (1ul << eIntFormatIntBin) | (1ul << eIntFormatIntOOct) \
     | (1ul << eIntFormatIntQOct))
#define eIntFormatMaskMoto \
    ((1ul << eIntFormatMotHex) | (1ul << eIntFormatMotBin) | (1ul << eIntFormatMotOct))
#define eIntFormatMaskIBM                                                                \
    ((1ul << eIntFormatIBMXHex) | (1ul << eIntFormatIBMHHex) | (1ul << eIntFormatIBMBin) \
     | (1ul << eIntFormatIBMOct))

typedef enum eIntConstMode {
    eIntConstModeIntel, /* Hex xxxxh, Oct xxxxo, Bin xxxxb */
    eIntConstModeMoto,  /* Hex $xxxx, Oct @xxxx, Bin %xxxx */
    eIntConstModeC,     /* Hex 0x..., Oct 0...., Bin 0b... */
    eIntConstModeIBM    /* Hex 'xxxx['], Oct o'xxxx['], Bin b'xxxx['] */
} tIntConstMode;

typedef struct {
    char const* pExpr;
    size_t      ExprLen;
    int         Base;
} tIntCheckCtx;

typedef Boolean (*tIntFormatCheck)(tIntCheckCtx* pCtx, char Ch);

typedef struct {
    tIntFormatCheck Check;
    Byte            Id;
    ShortInt        Base;
    char            Ch;
    char            Ident[7];
} tIntFormatList;

extern LongWord        NativeIntConstModeMask, OtherIntConstModeMask;
extern tIntFormatList* IntFormatList;
extern Boolean         RelaxedMode;
extern int             RadixBase;

extern char const* GetIntConstMotoPrefix(unsigned Radix);
extern char const* GetIntConstIntelSuffix(unsigned Radix);
extern char const* GetIntConstIBMPrefix(unsigned Radix);
extern char const* GetIntConstIBMSuffix(unsigned Radix);
extern char const* GetIntConstCPrefix(unsigned Radix);

extern void    SetIntConstModeByMask(LongWord Mask);
extern Boolean ModifyIntConstModeByMask(LongWord ANDMask, LongWord ORMask);

extern void SetIntConstMode(tIntConstMode Mode);

extern void SetIntConstRelaxedMode(Boolean NewRelaxedMode);

extern tIntFormatId GetIntFormatId(char const* pIdent);

extern void intformat_init(void);

#endif /* INTFORMAT_H */
